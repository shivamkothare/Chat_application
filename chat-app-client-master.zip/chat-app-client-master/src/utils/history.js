// const createHistory = require("history")

module.exports = require("history").createHashHistory();
